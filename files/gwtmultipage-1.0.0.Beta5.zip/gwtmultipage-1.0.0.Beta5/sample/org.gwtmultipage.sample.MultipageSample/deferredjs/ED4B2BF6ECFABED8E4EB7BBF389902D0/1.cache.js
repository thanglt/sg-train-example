function uq(){}
function Gq(){return lo}
function Kq(){var a;while(zq){zq=zq.b;!zq&&(Aq=null);a=Tu(new Ru,GM);au((Zu(),bv(null)),a)}}
function Hq(){Cq=true;Bq=(Eq(),new uq);Be((ye(),xe),1);!!$stats&&$stats(ff(EM,GG,null,null));Bq.r();!!$stats&&$stats(ff(EM,FM,null,null))}
var HM='AsyncLoader1',GM='This is MultipageEntryPointTwo (Two.html)',EM='runCallbacks1';_=uq.prototype=new vq;_.gC=Gq;_.r=Kq;_.tI=0;var lo=zw(SK,HM);Hq();