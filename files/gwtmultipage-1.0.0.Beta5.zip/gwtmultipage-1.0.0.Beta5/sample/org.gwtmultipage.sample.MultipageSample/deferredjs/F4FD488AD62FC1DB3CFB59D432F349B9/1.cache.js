function yq(){}
function Kq(){return po}
function Oq(){var a;while(Dq){Dq=Dq.b;!Dq&&(Eq=null);a=Vu(new Tu,EM);cu((_u(),dv(null)),a)}}
function Lq(){Gq=true;Fq=(Iq(),new yq);Be((ye(),xe),1);!!$stats&&$stats(ff(CM,HG,null,null));Fq.r();!!$stats&&$stats(ff(CM,DM,null,null))}
var FM='AsyncLoader1',EM='This is MultipageEntryPointTwo (Two.html)',CM='runCallbacks1';_=yq.prototype=new zq;_.gC=Kq;_.r=Oq;_.tI=0;var po=Bw(QK,FM);Lq();