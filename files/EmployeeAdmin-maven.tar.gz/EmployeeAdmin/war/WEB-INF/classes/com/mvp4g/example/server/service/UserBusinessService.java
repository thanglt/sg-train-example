package com.mvp4g.example.server.service;

import java.util.List;

import org.springframework.security.annotation.Secured;



import com.mvp4g.example.client.bean.UserBean;


public interface UserBusinessService {

	@Secured({"ROLE_USER"})
	public List<UserBean> getUsers();

	@Secured({"ROLE_ADMIN"})
	public void deleteUser( UserBean user );

	@Secured({"ROLE_ADMIN"})
	public void createUser( UserBean user );

	@Secured({"ROLE_ADMIN"})
	public void updateUser( UserBean user );	
}
