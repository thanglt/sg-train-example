package com.mvp4g.example.client;

import java.util.List;

import org.springframework.security.annotation.Secured;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;
import com.gwtincubator.security.exception.ApplicationSecurityException;
import com.mvp4g.example.client.bean.UserBean;

@RemoteServiceRelativePath( "userService.rpc" )
public interface UserService extends RemoteService {

	@Secured({"ROLE_USER"})
	public List<UserBean> getUsers() throws ApplicationSecurityException;

	@Secured({"ROLE_ADMIN"})
	public void deleteUser( UserBean user ) throws ApplicationSecurityException;

	@Secured({"ROLE_ADMIN"})
	public void createUser( UserBean user ) throws ApplicationSecurityException;

	@Secured({"ROLE_ADMIN"})
	public void updateUser( UserBean user ) throws ApplicationSecurityException;

}
