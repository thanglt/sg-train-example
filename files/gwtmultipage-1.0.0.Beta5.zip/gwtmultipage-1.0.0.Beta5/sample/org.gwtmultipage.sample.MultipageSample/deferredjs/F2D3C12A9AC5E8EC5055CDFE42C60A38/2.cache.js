function qr(){}
function Cr(){return Po}
function Gr(){var a;while(vr){vr=vr.b;!vr&&(wr=null);a=nv(new lv,gN);wu((tv(),xv(null)),a)}}
function Dr(){yr=true;xr=(Ar(),new qr);Ee((Be(),Ae),2);!!$stats&&$stats(jf(fN,cH,null,null));xr.v();!!$stats&&$stats(jf(fN,cN,null,null))}
var hN='AsyncLoader2',gN='This is UrlPatternPage (UrlPattern.html)',fN='runCallbacks2';_=qr.prototype=new rr;_.gC=Cr;_.v=Gr;_.tI=0;var Po=Vw(pL,hN);Dr();