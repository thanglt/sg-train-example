function Wq(){}
function gr(){return to}
function kr(){var a;while(_q){_q=_q.b;!_q&&(ar=null);a=Vu(new Tu,HM);cu((_u(),dv(null)),a)}}
function hr(){cr=true;br=(er(),new Wq);Be((ye(),xe),2);!!$stats&&$stats(ff(GM,HG,null,null));br.r();!!$stats&&$stats(ff(GM,DM,null,null))}
var IM='AsyncLoader2',HM='This is UrlPatternPage (UrlPattern.html)',GM='runCallbacks2';_=Wq.prototype=new Xq;_.gC=gr;_.r=kr;_.tI=0;var to=Bw(QK,IM);hr();