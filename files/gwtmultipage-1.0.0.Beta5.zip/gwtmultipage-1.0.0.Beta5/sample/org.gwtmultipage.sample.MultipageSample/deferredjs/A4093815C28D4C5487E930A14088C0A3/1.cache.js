function Bq(){}
function Nq(){return ro}
function Rq(){var a;while(Gq){Gq=Gq.a;!Gq&&(Hq=null);a=fv(new dv,gN);ou((lv(),pv(null)),a)}}
function Oq(){Jq=true;Iq=(Lq(),new Bq);Ae((xe(),we),1);!!$stats&&$stats(ef(eN,UG,null,null));Iq.r();!!$stats&&$stats(ef(eN,fN,null,null))}
var hN='AsyncLoader1',gN='This is MultipageEntryPointTwo (Two.html)',eN='runCallbacks1';_=Bq.prototype=new Cq;_.gC=Nq;_.r=Rq;_.tI=0;var ro=Nw(qL,hN);Oq();