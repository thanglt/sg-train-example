package com.mvp4g.example.client.view.widget;

import com.google.gwt.user.client.ui.TextBox;
import com.mvp4g.example.client.presenter.view_interface.widget_interface.MyTextBoxInterface;

public class MyTextBox extends TextBox implements MyTextBoxInterface {

}
