function Sr(){}
function cs(){return Do}
function gs(){var a;while(Xr){Xr=Xr.b;!Xr&&(Yr=null);a=Zu(new Xu,WM);gu((dv(),hv(null)),a)}}
function ds(){$r=true;Zr=(as(),new Sr);Ce((ze(),ye),4);!!$stats&&$stats(gf(VM,MG,null,null));Zr.r();!!$stats&&$stats(gf(VM,MM,null,null))}
var XM='AsyncLoader4',WM='This is JavascriptTokenPage (JavascriptToken.html)',VM='runCallbacks4';_=Sr.prototype=new Tr;_.gC=cs;_.r=gs;_.tI=0;var Do=Fw(ZK,XM);ds();