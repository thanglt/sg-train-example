package com.mvp4g.example.server.gwt;


import java.util.List;

import com.gwtincubator.security.exception.ApplicationSecurityException;
import com.mvp4g.example.client.Constants;
import com.mvp4g.example.client.UserService;
import com.mvp4g.example.client.bean.UserBean;
import com.mvp4g.example.server.service.UserBusinessService;

public class UserServiceImpl implements UserService, Constants {
	
	private UserBusinessService userBusinessService;

	private static final long serialVersionUID = 263606265567100312L;


	public List<UserBean> getUsers()throws ApplicationSecurityException {
		return userBusinessService.getUsers();
	}

	public void deleteUser( UserBean user )throws ApplicationSecurityException {
		// deletion always succeeds		
		userBusinessService.deleteUser(user);
	}

	public void createUser( UserBean user )throws ApplicationSecurityException {
		// creation always succeeds		
		userBusinessService.createUser(user);
	}

	public void updateUser( UserBean user )throws ApplicationSecurityException {
		// update always succeeds		
		userBusinessService.updateUser(user);
		
	}

	public UserBusinessService getUserBusinessService() {
		return userBusinessService;
	}

	public void setUserBusinessService(UserBusinessService userBusinessService) {
		this.userBusinessService = userBusinessService;
	}
	
	

}
