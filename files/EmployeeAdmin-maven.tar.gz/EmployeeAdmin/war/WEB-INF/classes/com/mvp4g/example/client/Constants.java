package com.mvp4g.example.client;

public interface Constants {

	public static final String[] DEPARTMENTS = { "Accounting", "Sales", "Plant" };
	public static final String[] ROLES = { "Administrator", "Accounts Payable", "Accounts Receivable", "Employee Benefits", "General Ledger",
			"Payroll", "Inventory", "Production", "Quality Control", "Sales", "Orders", "Customers", "Shipping", "Returns" };

}
