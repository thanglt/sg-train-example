
/*

  SmartClient Ajax RIA system
  Version SC_SNAPSHOT-2011-05-03/EVAL Deployment (2011-05-03)

  Copyright 2000 and beyond Isomorphic Software, Inc. All rights reserved.
  "SmartClient" is a trademark of Isomorphic Software, Inc.

  LICENSE NOTICE
     INSTALLATION OR USE OF THIS SOFTWARE INDICATES YOUR ACCEPTANCE OF
     ISOMORPHIC SOFTWARE LICENSE TERMS. If you have received this file
     without an accompanying Isomorphic Software license file, please
     contact licensing@isomorphic.com for details. Unauthorized copying and
     use of this software is a violation of international copyright law.

  DEVELOPMENT ONLY - DO NOT DEPLOY
     This software is provided for evaluation, training, and development
     purposes only. It may include supplementary components that are not
     licensed for deployment. The separate DEPLOY package for this release
     contains SmartClient components that are licensed for deployment.

  PROPRIETARY & PROTECTED MATERIAL
     This software contains proprietary materials that are protected by
     contract and intellectual property law. You are expressly prohibited
     from attempting to reverse engineer this software or modify this
     software for human readability.

  CONTACT ISOMORPHIC
     For more information regarding license rights and restrictions, or to
     report possible license violations, please contact Isomorphic Software
     by email (licensing@isomorphic.com) or web (www.isomorphic.com).

*/

if(window.isc&&window.isc.module_Core&&!window.isc.module_RealtimeMessaging){isc.module_RealtimeMessaging=1;isc._moduleStart=isc._RealtimeMessaging_start=(isc.timestamp?isc.timestamp():new Date().getTime());if(isc._moduleEnd&&(!isc.Log||(isc.Log && isc.Log.logIsDebugEnabled('loadTime')))){isc._pTM={ message:'RealtimeMessaging load/parse time: ' + (isc._moduleStart-isc._moduleEnd) + 'ms', category:'loadTime'};
if(isc.Log && isc.Log.logDebug)isc.Log.logDebug(isc._pTM.message,'loadTime')
else if(isc._preLog)isc._preLog[isc._preLog.length]=isc._pTM
else isc._preLog=[isc._pTM]}isc.definingFramework=true;isc.ClassFactory.defineClass("Messaging");isc.A=isc.Messaging;isc.A.messagingURL="[ISOMORPHIC]/messaging";isc.A.$59y=1;isc.A.$59z=null;isc.A.$590=null;isc.A._channels={};isc.A.$591=[];isc.A.$592=20;isc.A.connectTimeout=4000;isc.A=isc.Messaging;isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.B.push(isc.A.send=function isc_c_Messaging_send(_1,_2,_3){if(!isc.isAn.Array(_1))_1=[_1];isc.rpc.app().performOperation("messagingSend",{type:"send",sendToChannels:_1,subscribedChannels:this._channels,data:_2},"isc.Messaging.$593(rpcResponse)",{showPrompt:false,callback:_3,willHandleError:_3!=null})}
,isc.A.$593=function isc_c_Messaging__sendCallback(_1){}
,isc.A.getSubscribedChannels=function isc_c_Messaging_getSubscribedChannels(){return isc.getKeys(this._channels)}
,isc.A.subscribe=function isc_c_Messaging_subscribe(_1,_2,_3){if(!this._channels[_1]){this._channels[_1]={};if(_3)this._channels[_1].data=_3;this.$594()}
this._channels[_1].callback=_2;return}
,isc.A.unsubscribe=function isc_c_Messaging_unsubscribe(_1){if(!this._channels[_1])return;delete this._channels[_1];this.$594();if(isc.isAn.emptyObject(this._channels))this.disconnect()}
,isc.A.connected=function isc_c_Messaging_connected(){return this._channels&&isc.getKeys(this._channels).length>0&&this.$595}
,isc.A.disconnect=function isc_c_Messaging_disconnect(){this._channels={};this.$59z=null;this.$590=null;this.$596=null;isc.Timer.clear(this.$597);this.$597=null;isc.Timer.clear(this.$598);this.$598=null}
,isc.A.$594=function isc_c_Messaging__reconnect(){if(!isc.Page.isLoaded()){isc.Page.setEvent("load","isc.Messaging.$594()");return}
if(!this.$597)
this.$597=isc.Timer.setTimeout("isc.Messaging.$599()",this.$59y,isc.Timer.MSEC)}
,isc.A.$60a=function isc_c_Messaging__connectRetry(){if(this.$590&&window[this.$590])window[this.$590].destroy();this.$590=null;this.logDebug("connect failed, retrying in: "+this.connectTimeout+"ms");this.$594()}
,isc.A._serverConnTerminate=function isc_c_Messaging__serverConnTerminate(){this.$594()}
,isc.A.$599=function isc_c_Messaging__connect(){isc.Timer.clear(this.$597);this.$597=null;if(this.$590){this.$60b=true;this.logDebug("connect pending - deferring openConnection request.");return}
if(this.getSubscribedChannels().length==0)return;var _1=isc.HiddenFrame.create();this.$590=_1.getID();var _2={type:"connect",connectionID:this.$590,subscribedChannels:isc.Comm.serialize(this._channels)}
isc.Comm.sendHiddenFrame({URL:isc.Page.getURL(this.messagingURL)+"?ts="+isc.timestamp(),fields:_2,transaction:{changed:function(){},requestData:_2},frame:_1});this.$60c=isc.Timer.setTimeout("isc.Messaging.$60a()",this.connectTimeout,isc.Timer.MSEC)}
,isc.A._connectCallback=function isc_c_Messaging__connectCallback(_1,_2){if(_1!=this.$590)return;this.$60d=_2.keepaliveInterval;this.$60e=_2.keepaliveReestablishDelay;this.$60f=this.$60d+this.$60e;this.$60g=_2.connectionTTL;this.connectTimeout=_2.connectTimeout;if(this.$59z&&window[this.$59z])window[this.$59z].destroy();this.$59z=this.$590;this.$590=null;isc.Timer.clear(this.$60c);this.$60h();this.$60i();this.logDebug("persistent server connection open - ttl: "+this.$60g+"ms, keepaliveDelay: "+this.$60f+"ms, connectTimeout: "+this.connectTimeout+"ms.")
if(this.$60b){this.$60b=false;this.$594();return}
var _3=isc.HiddenFrame.create();var _4=_3.getID();var _5={type:"establishAck",ackFrameID:_4};isc.Comm.sendHiddenFrame({URL:isc.Page.getURL(this.messagingURL)+"?ts="+isc.timestamp(),fields:_5,transaction:{changed:function(){},requestData:_5},frame:_3})}
,isc.A.$60h=function isc_c_Messaging__resetStatusBar(){var _1=isc.Browser.isIE?"Done":"Stopped";isc.Timer.setTimeout("window.status='"+_1+"'",0)}
,isc.A._establishAck=function isc_c_Messaging__establishAck(_1){if(_1&&window[_1])window[_1].destroy();this.$595=true}
,isc.A._keepalive=function isc_c_Messaging__keepalive(_1){this.$60h();if(_1!=this.$59z)return;this.$60i();this.logDebug("keepalive on conn: "+_1)}
,isc.A.$60j=function isc_c_Messaging__keepaliveWatchdog(){this.logDebug("connection to server lost, re-establishing...");this.$594()}
,isc.A.$60i=function isc_c_Messaging__resetKeepaliveTimer(){isc.Timer.clear(this.$598);this.$598=isc.Timer.setTimeout("isc.Messaging.$60j()",this.$60f,isc.Timer.MSEC)}
,isc.A._message=function(message){message=isc.eval("var message = "+message+";message;");var conn=message.conn,channels=message.channels,id=message.id,data=message.data;this.$60h();if(conn!=this.$59z)return;this.$60i();if(this.$591.contains(id)){this.logDebug("ignoring duplicate ID: "+id);return}
this.$591.push(id);if(this.$591.length>this.$592)this.$591.shift();for(var i=0;i<channels.length;i++){var channel=channels[i];if(!this._channels[channel])continue;var channel=this._channels[channel],callback=channel.callback
if(callback)this.fireCallback(callback,"data",[data],channel)}}
,isc.A.$60k=function isc_c_Messaging__destroyConns(){if(this.$590!=null&&window[this.$590]!=null){window[this.$590].destroy()}
if(this.$59z!=null&&window[this.$59z]!=null){window[this.$59z].destroy()}
delete this.$59z;delete this.$590}
);isc.B._maxIndex=isc.C+19;isc.Page.setEvent("unload","isc.Messaging.$60k()");isc._moduleEnd=isc._RealtimeMessaging_end=(isc.timestamp?isc.timestamp():new Date().getTime());if(isc.Log&&isc.Log.logIsInfoEnabled('loadTime'))isc.Log.logInfo('RealtimeMessaging module init time: ' + (isc._moduleEnd-isc._moduleStart) + 'ms','loadTime');delete isc.definingFramework;}else{if(window.isc && isc.Log && isc.Log.logWarn)isc.Log.logWarn("Duplicate load of module 'RealtimeMessaging'.");}

/*

  SmartClient Ajax RIA system
  Version SC_SNAPSHOT-2011-05-03/EVAL Deployment (2011-05-03)

  Copyright 2000 and beyond Isomorphic Software, Inc. All rights reserved.
  "SmartClient" is a trademark of Isomorphic Software, Inc.

  LICENSE NOTICE
     INSTALLATION OR USE OF THIS SOFTWARE INDICATES YOUR ACCEPTANCE OF
     ISOMORPHIC SOFTWARE LICENSE TERMS. If you have received this file
     without an accompanying Isomorphic Software license file, please
     contact licensing@isomorphic.com for details. Unauthorized copying and
     use of this software is a violation of international copyright law.

  DEVELOPMENT ONLY - DO NOT DEPLOY
     This software is provided for evaluation, training, and development
     purposes only. It may include supplementary components that are not
     licensed for deployment. The separate DEPLOY package for this release
     contains SmartClient components that are licensed for deployment.

  PROPRIETARY & PROTECTED MATERIAL
     This software contains proprietary materials that are protected by
     contract and intellectual property law. You are expressly prohibited
     from attempting to reverse engineer this software or modify this
     software for human readability.

  CONTACT ISOMORPHIC
     For more information regarding license rights and restrictions, or to
     report possible license violations, please contact Isomorphic Software
     by email (licensing@isomorphic.com) or web (www.isomorphic.com).

*/

