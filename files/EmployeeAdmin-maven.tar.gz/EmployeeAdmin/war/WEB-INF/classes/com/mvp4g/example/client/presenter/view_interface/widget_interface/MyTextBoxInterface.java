package com.mvp4g.example.client.presenter.view_interface.widget_interface;

import com.google.gwt.event.dom.client.HasKeyUpHandlers;
import com.google.gwt.user.client.ui.HasValue;

public interface MyTextBoxInterface extends HasValue<String>, HasKeyUpHandlers {

}
