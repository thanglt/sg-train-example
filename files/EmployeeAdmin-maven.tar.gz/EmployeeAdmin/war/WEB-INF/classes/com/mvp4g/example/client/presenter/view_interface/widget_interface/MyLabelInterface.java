package com.mvp4g.example.client.presenter.view_interface.widget_interface;

public interface MyLabelInterface {

	public void setVisible( boolean visible );

}
