function Sq(){}
function cr(){return po}
function gr(){var a;while(Xq){Xq=Xq.b;!Xq&&(Yq=null);a=Tu(new Ru,JM);au((Zu(),bv(null)),a)}}
function dr(){$q=true;Zq=(ar(),new Sq);Be((ye(),xe),2);!!$stats&&$stats(ff(IM,GG,null,null));Zq.r();!!$stats&&$stats(ff(IM,FM,null,null))}
var KM='AsyncLoader2',JM='This is UrlPatternPage (UrlPattern.html)',IM='runCallbacks2';_=Sq.prototype=new Tq;_.gC=cr;_.r=gr;_.tI=0;var po=zw(SK,KM);dr();