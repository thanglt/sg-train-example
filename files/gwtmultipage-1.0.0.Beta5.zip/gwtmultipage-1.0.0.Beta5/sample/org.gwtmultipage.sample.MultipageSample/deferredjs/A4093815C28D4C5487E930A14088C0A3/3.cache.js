function vr(){}
function Hr(){return zo}
function Lr(){var a;while(Ar){Ar=Ar.a;!Ar&&(Br=null);a=fv(new dv,mN);ou((lv(),pv(null)),a)}}
function Ir(){Dr=true;Cr=(Fr(),new vr);Ae((xe(),we),3);!!$stats&&$stats(ef(lN,UG,null,null));Cr.r();!!$stats&&$stats(ef(lN,fN,null,null))}
var nN='AsyncLoader3',mN='This is MultipageEntryPointIndex (index.html)',lN='runCallbacks3';_=vr.prototype=new wr;_.gC=Hr;_.r=Lr;_.tI=0;var zo=Nw(qL,nN);Ir();