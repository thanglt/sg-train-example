function Uq(){}
function er(){return Lo}
function ir(){var a;while(Zq){Zq=Zq.b;!Zq&&($q=null);a=nv(new lv,dN);wu((tv(),xv(null)),a)}}
function fr(){ar=true;_q=(cr(),new Uq);Ee((Be(),Ae),1);!!$stats&&$stats(jf(bN,cH,null,null));_q.v();!!$stats&&$stats(jf(bN,cN,null,null))}
var eN='AsyncLoader1',dN='This is MultipageEntryPointTwo (Two.html)',bN='runCallbacks1';_=Uq.prototype=new Vq;_.gC=er;_.v=ir;_.tI=0;var Lo=Vw(pL,eN);fr();