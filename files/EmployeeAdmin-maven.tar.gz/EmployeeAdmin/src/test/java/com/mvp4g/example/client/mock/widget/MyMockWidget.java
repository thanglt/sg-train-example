package com.mvp4g.example.client.mock.widget;

import com.google.gwt.user.client.ui.Widget;
import com.mvp4g.example.client.presenter.view_interface.widget_interface.MyWidgetInterface;

public class MyMockWidget implements MyWidgetInterface {

	public Widget getMyWidget() {
		return null;
	}

}
