function Aq(){}
function Mq(){return ro}
function Qq(){var a;while(Fq){Fq=Fq.b;!Fq&&(Gq=null);a=Zu(new Xu,NM);gu((dv(),hv(null)),a)}}
function Nq(){Iq=true;Hq=(Kq(),new Aq);Ce((ze(),ye),1);!!$stats&&$stats(gf(LM,MG,null,null));Hq.r();!!$stats&&$stats(gf(LM,MM,null,null))}
var OM='AsyncLoader1',NM='This is MultipageEntryPointTwo (Two.html)',LM='runCallbacks1';_=Aq.prototype=new Bq;_.gC=Mq;_.r=Qq;_.tI=0;var ro=Fw(ZK,OM);Nq();