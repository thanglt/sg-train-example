package com.mvp4g.example.client.view.widget;

import com.google.gwt.user.client.ui.PasswordTextBox;
import com.mvp4g.example.client.presenter.view_interface.widget_interface.MyTextBoxInterface;

public class MyPasswordTextBox extends PasswordTextBox implements MyTextBoxInterface {

}
