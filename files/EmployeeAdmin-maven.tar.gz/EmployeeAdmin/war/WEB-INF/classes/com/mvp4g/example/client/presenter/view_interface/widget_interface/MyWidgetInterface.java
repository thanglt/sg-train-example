package com.mvp4g.example.client.presenter.view_interface.widget_interface;

import com.google.gwt.user.client.ui.Widget;

public interface MyWidgetInterface {

	public Widget getMyWidget();

}
