function Yq(){}
function ir(){return vo}
function mr(){var a;while(br){br=br.b;!br&&(cr=null);a=Zu(new Xu,QM);gu((dv(),hv(null)),a)}}
function jr(){er=true;dr=(gr(),new Yq);Ce((ze(),ye),2);!!$stats&&$stats(gf(PM,MG,null,null));dr.r();!!$stats&&$stats(gf(PM,MM,null,null))}
var RM='AsyncLoader2',QM='This is UrlPatternPage (UrlPattern.html)',PM='runCallbacks2';_=Yq.prototype=new Zq;_.gC=ir;_.r=mr;_.tI=0;var vo=Fw(ZK,RM);jr();