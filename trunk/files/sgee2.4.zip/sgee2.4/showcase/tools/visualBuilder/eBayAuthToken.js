isc.EBay.setSandboxToken(
// Provide your sandbox token here as a JavaScript string.  E.g: "myauthtoken"

);
isc.EBay.setProductionToken(
// Provide your production token here as a JavaScript string.  E.g: "myauthtoken"

);