function Zq(){}
function jr(){return vo}
function nr(){var a;while(cr){cr=cr.a;!cr&&(dr=null);a=fv(new dv,jN);ou((lv(),pv(null)),a)}}
function kr(){fr=true;er=(hr(),new Zq);Ae((xe(),we),2);!!$stats&&$stats(ef(iN,UG,null,null));er.r();!!$stats&&$stats(ef(iN,fN,null,null))}
var kN='AsyncLoader2',jN='This is UrlPatternPage (UrlPattern.html)',iN='runCallbacks2';_=Zq.prototype=new $q;_.gC=jr;_.r=nr;_.tI=0;var vo=Nw(qL,kN);kr();