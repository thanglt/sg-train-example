function ur(){}
function Gr(){return zo}
function Kr(){var a;while(zr){zr=zr.b;!zr&&(Ar=null);a=Zu(new Xu,TM);gu((dv(),hv(null)),a)}}
function Hr(){Cr=true;Br=(Er(),new ur);Ce((ze(),ye),3);!!$stats&&$stats(gf(SM,MG,null,null));Br.r();!!$stats&&$stats(gf(SM,MM,null,null))}
var UM='AsyncLoader3',TM='This is MultipageEntryPointIndex (index.html)',SM='runCallbacks3';_=ur.prototype=new vr;_.gC=Gr;_.r=Kr;_.tI=0;var zo=Fw(ZK,UM);Hr();